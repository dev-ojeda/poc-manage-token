import { ApiClient } from "../api/ApiClient.js";
import { showGlobalAlert } from "../layout.js";
import { handleError } from "../utils/errors.js";

/**
 * Clase especializada para la gestión de usuarios finales.
 * Hereda de ApiClient y agrega manejo de tokens, login, logout, etc.
 */
export class ApiUser extends ApiClient {
    constructor(opts) {
        super({
            baseURL: opts.baseURL,
            storage: opts.storage,
            timeout: opts.timeout || 10000,
            debugEnabled: opts.debugEnabled || false // ✅ viene de afuera
        });

        this.isRefreshing = false;   // Lock para evitar múltiples refresh simultáneos
        this.refreshQueue = [];      // Cola de promesas esperando refresh
        // ✅ Agregar:
    }

    // =======================
    // Login de Usuario
    // =======================
    async login(username, password) {
        try {
            const device = await this.getDeviceId();
            const user_agent = this.getBrowserInfo();

            const res = await this.fetchJson("/api/auth/acceso", {
                method: "POST",
                body: JSON.stringify({ username, password, device, rol: "User", user_agent }),
            });
            this._debug("login → Resultado:", res);
            if (res?.access_token && res?.refresh_token) {
                await this.setTokens({ access_token: res.access_token, refresh_token: res.refresh_token, rol: res.rol });  // ✅ corregido: se llama correctamente
            }

            return res;
        } catch (err) {
            await handleError(err);
            this._debug("login → Error:", err);
            return null;
        }
    }

    // =======================
    // Logout Unificado
    // =======================
    async logout({ reason = "logout" } = {}) {
        try {
            debugger;
            this._info("logout → reason:", reason);
            const access_token = await this.accessToken("user");
            const refresh_token = await this.refreshToken("user");
            const device_id = await this.getDeviceId();
            const user_agent = this.getBrowserInfo();

            if (!access_token && !refresh_token) throw new Error("Token no existe");

            const res = await this.fetchJson("/api/auth/logout", {
                method: "POST",
                body: JSON.stringify({ access_token, refresh_token, device_id, user_agent, reason }),
            });
            this._info("logout → res:", res);
            this.notifier?.(`👋 ${res?.msg || "Sesión finalizada"}`, "info", 4000);
        } catch (err) {
            this._error("logout → reason:", reason);
            await handleError(err);
        } finally {
            // Limpieza local y evento global
            await this.storage.delete("access_token_user");
            await this.storage.delete("refresh_token_user");
            document.dispatchEvent(new CustomEvent("userLoggedOut"));
            location.replace("/?logout=true");
        }
    }

    // =======================
    // Cargar datos del dashboard (usuario)
    // =======================
    async loadInfoUser() {
        try {
            const res = await this.fetchJson("/api/auth/dashboard");
            this._debug("loadInfoUser() → Resultado:", res);
            return res; 
        } catch (err) {
            await handleError(err);
            return null;
        }
    }

    // =======================
    // Fetch con token + reintento automático
    // =======================
    async fetchWithAuth(url, options = {}) {
        let access_token = await this.accessTokenUser();

        const baseHeaders = {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${access_token}`,
            "X-Token-Type": "access",
        };

        let res = await fetch(url, {
            ...options,
            headers: { ...baseHeaders, ...(options.headers || {}) },
        });

        if (res.status === 401) {
            await this.tryRefreshToken();
            access_token = await this.accessTokenUser();
            res = await fetch(url, {
                ...options,
                headers: { ...baseHeaders, "Authorization": `Bearer ${access_token}` },
            });
        }

        return res;
    }

    // =======================
    // Refresh token con lock
    // =======================
    async tryRefreshToken() {
        if (this.isRefreshing) {
            return new Promise((resolve, reject) => this.refreshQueue.push({ resolve, reject }));
        }

        this.isRefreshing = true;

        try {
            const refresh_token = await this.refreshToken("user");
            if (!refresh_token) throw new Error("No hay refresh_token disponible");

            const device_id = await this.getDeviceId();
            const user_agent = this.getBrowserInfo();

            const res = await this.fetchJson("/api/auth/refresh", {
                method: "POST",
                body: JSON.stringify({ refresh_token, device_id, user_agent }),
            });

            if (res?.access_token) {
                await this.setTokens(res);
                const decoded = this.decodeJwt(res.access_token);
                document.dispatchEvent(new CustomEvent("startTokenTimer", { detail: { new_expiracion: decoded.exp } }));

                this.refreshQueue.forEach((p) => p.resolve(res));
                this.refreshQueue = [];
            }

            return res;
        } catch (err) {
            this.refreshQueue.forEach((p) => p.reject(err));
            this.refreshQueue = [];
            await handleError(err);
            throw err;
        } finally {
            this.isRefreshing = false;
        }
    }

    // =======================
    // Decode JWT
    // =======================
    decodeJwt(token) {
        try {
            return JSON.parse(atob(token.split(".")[1]));
        } catch {
            return {};
        }
    }

    // =======================
    // CRUD Items (User Scope)
    // =======================
    async loadItems() {
        try {
            return await this.fetchJson("/api/auth/user/items");
        } catch (err) {
            await handleError(err);
            return null;
        }
    }

    async createItem(data = {}) {
        try {
            const res = await this.fetchJson("/api/auth/user/items", {
                method: "POST",
                body: JSON.stringify(data),
            });
            this.notifier?.(`✅ ${res.msg}`, "success", 4000);
        } catch (err) {
            await handleError(err);
            return null;
        }
    }

    async updateItem(id, data) {
        try {
            await this.fetchJson(`/api/auth/user/items/${id}`, {
                method: "PUT",
                body: JSON.stringify(data),
            });
            return await this.loadItems();
        } catch (err) {
            await handleError(err);
            return null;
        }
    }

    async deleteItem(id) {
        try {
            await this.fetchJson(`/api/auth/user/items/${id}`, { method: "DELETE" });
            return await this.loadItems();
        } catch (err) {
            await handleError(err);
            return null;
        }
    }

    async loadDashboard() {

        this._debug("loadDashboard → Iniciando carga de partial...");
        const container = document.getElementById("mainContent");
        if (!container) return;

        try {
            const html = await this.fetchHtml("/user/partial");
            container.innerHTML = html;
            this._debug("loadDashboard → Resultado:", html);
        } catch (err) {
            console.error("Error al cargar dashboard SPA:", err);
            showGlobalAlert("No se pudo cargar el panel. Verifica tu conexión o sesión.", "warning", 4000);
            this._debug("loadDashboard → Error:", err);
            container.innerHTML = `
                <div class="text-center py-5 text-muted">
                    <i class="bi bi-cloud-slash display-6 d-block mb-3"></i>
                    <p>Ups... no pudimos cargar el contenido del dashboard.</p>
                    <button id="retryDashboardBtn" class="btn btn-outline-success btn-sm">
                        <i class="bi bi-arrow-repeat me-1"></i> Reintentar
                    </button>
                </div>`;
            document.getElementById("retryDashboardBtn")?.addEventListener("click", () => this.loadDashboard());
        }
    }

    // =======================
    // DEBUG UTILS
    // =======================
    // =============================
    // 🔹 Logger Inteligente
    // =============================
    _log(level = "info", label = "", ...args) {
        if (!this.debugEnabled) return;

        const time = new Date().toLocaleTimeString();
        const styles = {
            info: "color:#0dcaf0; font-weight:bold;",
            warn: "color:#ffc107; font-weight:bold;",
            error: "color:#dc3545; font-weight:bold;",
            success: "color:#28a745; font-weight:bold;",
            debug: "color:#6f42c1; font-weight:bold;"
        };

        const prefix = {
            info: "ℹ️",
            warn: "⚠️",
            error: "💥",
            success: "✅",
            debug: "🧠"
        }[level] || "🔹";

        console.groupCollapsed(`%c${prefix} [${level.toUpperCase()} ${time}] ${label}`, styles[level] || styles.info);
        console.log(...args);
        console.groupEnd();
        // 🔹 Nuevo → emite al panel flotante
        document.dispatchEvent(new CustomEvent("debug:log", { detail: { label, args } }));
    }

    // Aliases cortos
    _debug(label, ...args) { this._log("debug", label, ...args); }
    _info(label, ...args) { this._log("info", label, ...args); }
    _warn(label, ...args) { this._log("warn", label, ...args); }
    _error(label, ...args) { this._log("error", label, ...args); }
    _success(label, ...args) { this._log("success", label, ...args); }
    // =======================
    // Dashboard HTML (SPA)
    // =======================
    //async fetchDashboardHtml() {
    //    try {
    //        return await this.fetchHtml("/user/partial");
    //    } catch (err) {
    //        await handleError(err);
    //        return "";
    //    }
    //}
}
