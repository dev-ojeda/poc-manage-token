// ==============================
// api/ApiClient.js (v2.0)
// ==============================

import { showGlobalAlert, GLOBAL_DEBUG } from "../layout.js";
import { handleError } from "../utils/errors.js";

export class ApiClient {
    constructor({ baseURL, storage, timeout = 10000, notifier = showGlobalAlert, debugEnabled = GLOBAL_DEBUG }) {
        this.baseURL = baseURL;
        this.storage = storage;
        this.timeout = timeout;
        this.notifier = notifier;
        this.debugEnabled = debugEnabled;
    }

    // =============================
    // 🔹 Helpers internos
    // =============================
    _log(level = "info", label = "", ...args) {
        if (!this.debugEnabled) return;

        const time = new Date().toLocaleTimeString();
        const styles = {
            info: "color:#0dcaf0; font-weight:bold;",
            warn: "color:#ffc107; font-weight:bold;",
            error: "color:#dc3545; font-weight:bold;",
            success: "color:#28a745; font-weight:bold;",
            debug: "color:#6f42c1; font-weight:bold;"
        };

        const prefix = {
            info: "ℹ️",
            warn: "⚠️",
            error: "💥",
            success: "✅",
            debug: "🧠"
        }[level] || "🔹";

        console.groupCollapsed(`%c${prefix} [${level.toUpperCase()} ${time}] ${label}`, styles[level] || styles.info);
        console.log(...args);
        console.groupEnd();
    }

    // Aliases cortos
    _debug(label, ...args) { this._log("debug", label, ...args); }
    _info(label, ...args) { this._log("info", label, ...args); }
    _warn(label, ...args) { this._log("warn", label, ...args); }
    _error(label, ...args) { this._log("error", label, ...args); }
    _success(label, ...args) { this._log("success", label, ...args); }

    async safeGet(key) {
        try {
            return await this.storage.get(key);
        } catch (err) {
            this._error(`Error leyendo ${key}:`, err);
            return null;
        }
    }

    async _saveUserData(data) {
        const entries = Object.entries(data).filter(([_, v]) => v !== undefined && v !== null);
        await Promise.allSettled(entries.map(([k, v]) => this.storage.set(k, v)));
    }

    async clearTokens() {
        await this.storage.clear();
    }

    async getDeviceId() {
        let device = await this.safeGet("device_id");
        if (!device) {
            device = crypto.randomUUID();
            await this.storage.set("device_id", device);
        }
        return device;
    }

    getBrowserInfo() {
        const ua = navigator.userAgent;
        const browser =
            ua.includes("Chrome") && !ua.includes("Edg") ? "Chrome" :
                ua.includes("Firefox") ? "Firefox" :
                    ua.includes("Safari") && !ua.includes("Chrome") ? "Safari" :
                        ua.includes("Edg") ? "Edge" :
                            ua.includes("OPR") ? "Opera" : "Desconocido";

        const os =
            ua.includes("Windows") ? "Windows" :
                ua.includes("Mac OS") ? "MacOS" :
                    ua.includes("Linux") ? "Linux" :
                        /Android/.test(ua) ? "Android" :
                            /iPhone|iPad|iPod/.test(ua) ? "iOS" : "Desconocido";

        return { browser, os };
    }

    // =============================
    // 🔹 Token management
    // =============================
    async userRol() {
        const rol = await this.safeGet("rol");
        return (rol?.value || rol || "user").toLowerCase();
    }

    async accessToken(rol = null) {
        this._debug(rol);
        rol = rol || await this.userRol();
        const key = rol === "admin" ? "access_token_admin" : "access_token_user";
        const token = await this.safeGet(key);
        return token?.value || token;
    }

    async refreshToken(rol = null) {
        rol = rol || await this.userRol();
        const key = rol === "admin" ? "refresh_token_admin" : "refresh_token_user";
        const token = await this.safeGet(key);
        return token?.value || token;
    }

    async setTokens({ access_token, refresh_token, rol = "user" }) {
        rol = String(rol).toLowerCase();
        const prefix = rol === "admin" ? "admin" : "user";
        await this._saveUserData({
            [`access_token_${prefix}`]: access_token,
            [`refresh_token_${prefix}`]: refresh_token,
            rol
        });
    }

    // =============================
    // 🔹 Fetch wrappers
    // =============================
    async fetchJson(endpoint, options = {}) {
        return this._doFetch(endpoint, options, "json");
    }

    async fetchHtml(endpoint, options = {}) {
        return this._doFetch(endpoint, options, "text");
    }

    async fetchBlob(endpoint, options = {}) {
        return this._doFetch(endpoint, options, "blob");
    }

    // =============================
    // 🔹 Núcleo de comunicación
    // =============================
    async _doFetch(endpoint, options = {}, type = "json", _retry = false) {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), this.timeout);
        const rol = await this.userRol();
        const token = await this.accessToken(rol);
        this._debug("ROL",rol);
        this._debug("ENDPOINT",endpoint);
        try {
            const headers = {
                ...(type === "json" ? { "Content-Type": "application/json" } : {}),
                ...(options.headers || {}),
                ...(token ? { Authorization: `Bearer ${token}`, "X-Token-Type": "access" } : {})
            };

            this._debug("Fetch", { endpoint, rol, token: !!token, method: options.method || "GET" });

            const response = await this._retryableFetch(() =>
                fetch(`${this.baseURL}${endpoint}`, {
                    ...options,
                    headers,
                    signal: controller.signal
                }), 2, 400
            );

            clearTimeout(timeoutId);

            const contentType = response.headers.get("content-type") || "";
            let data;

            if (type === "json" || contentType.includes("application/json")) {
                data = await response.json().catch(() => ({}));
                if (!response.ok) {
                    if (response.status === 401 && !_retry) {
                        const refreshed = await this._tryRefreshToken(rol);
                        if (refreshed) return this._doFetch(endpoint, options, type, true);
                    }
                    this._throwHttpError(response, data);
                }
            } else {
                data = await response.text();
                if (!response.ok) throw { message: "Error al obtener contenido", code: response.status, raw: data };
            }

            return data;

        } catch (err) {
            clearTimeout(timeoutId);
            if (err.name === "AbortError") {
                this._error("⏱ Timeout: servidor no respondió", err);
                return handleError({ message: "⏱ Timeout: servidor no respondió", code: "TIMEOUT" });
            }
            if (err instanceof TypeError && err.message.includes("fetch")) {
                this._error("🌐 Error de red o servidor inaccesible", err);
                return handleError({ message: "🌐 Error de red o servidor inaccesible", code: "NETWORK_ERROR" });
            }
            this._error("Error interno", err);
            handleError(err);
        }
    }

    // =============================
    // 🔹 Reintentos y refresh
    // =============================
    async _retryableFetch(fn, retries = 2, delay = 400) {
        for (let i = 0; i <= retries; i++) {
            try {
                return await fn();
            } catch (err) {
                if (i === retries || err.name === "AbortError") throw err;
                this._debug(`Reintentando... (${i + 1}/${retries})`);
                await new Promise(r => setTimeout(r, delay * (i + 1)));
            }
        }
    }

    async _tryRefreshToken(rol) {
        try {
            const refresh = await this.refreshToken(rol);
            if (!refresh) return false;

            const response = await fetch(`${this.baseURL}/auth/refresh`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ refresh_token: refresh })
            });

            if (!response.ok) return false;
            const data = await response.json();
            await this.setTokens({ ...data, rol });
            this._debug("🔁 Token actualizado", data);
            return true;
        } catch (err) {
            this._debug("❌ Falló refresh token", err);
            await this.clearTokens();
            return false;
        }
    }

    // =============================
    // 🔹 Errores HTTP
    // =============================
    _throwHttpError(response, data) {
        const map = {
            401: { message: data.message || "No autorizado", code: "UNAUTHORIZED" },
            403: { message: `🚫 Bloqueado: ${data.msg}`, code: "FORBIDDEN" },
            409: { message: `⚠️ ${data.msg}`, code: "CONFLICT" },
            429: { message: "⏳ Límite excedido", code: "RATE_LIMIT" },
            500: { message: "💥 Error interno del servidor", code: "SERVER_ERROR" }
        };
        const err = map[response.status] || { message: data.msg || "Error desconocido", code: "UNKNOWN" };
        throw { ...err, status: response.status, raw: data, timestamp: new Date().toISOString() };
    }

    // =============================
    // 🔹 Métodos HTTP base
    // =============================
    async get(endpoint, options = {}) { return this.fetchJson(endpoint, { ...options, method: "GET" }); }
    async post(endpoint, body = {}, options = {}) {
        return this.fetchJson(endpoint, { ...options, method: "POST", body: JSON.stringify(body) });
    }
    async put(endpoint, body = {}, options = {}) {
        return this.fetchJson(endpoint, { ...options, method: "PUT", body: JSON.stringify(body) });
    }
    async delete(endpoint, options = {}) { return this.fetchJson(endpoint, { ...options, method: "DELETE" }); }
}
