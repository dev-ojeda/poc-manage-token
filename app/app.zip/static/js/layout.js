// js/layout.js
import { clearSession } from "../js/utils/errors.js";
import { IndexedDBStorage } from "./adapters/IndexedDBStorage.js";
import { ApiAdmin } from "./api/ApiAdmin.js";
import { ApiUser } from "./api/ApiUser.js";
export const GLOBAL_DEBUG = localStorage.getItem("debugMode") === "true";
const API_BASE = import.meta.env?.VITE_API_URL || "https://localhost:5000";
const storage = new IndexedDBStorage("AuthDB", "tokens");
//const metricsStorage = new MetricsStorage();
const api_admin = new ApiAdmin({
    baseURL: API_BASE,
    storage,
    debugEnabled: GLOBAL_DEBUG
});

const api_user = new ApiUser({
    baseURL: API_BASE,
    storage,
    debugEnabled: GLOBAL_DEBUG
});

/**
 * Bootstrap global init
 */
document.addEventListener("DOMContentLoaded", async () => {
    initSidebarToggle();
    await handleUrlAlerts();
    initGlobalEvents();
    initDebugPanel();
    initDebugConsole();
});

/* =======================================================
   1️⃣ Manejo de alertas globales (query params → UI)
   ======================================================= */
async function handleUrlAlerts() {
    const params = new URLSearchParams(window.location.search);
    const alerts = {
        logout: {
            msg: "⚠️ Tu sesión ha expirado. Por favor, iniciá sesión nuevamente.",
            type: "warning",
            clear: true,
        },
        unauthorized: {
            msg: "🚫 Acceso no autorizado. Iniciá sesión para continuar.",
            type: "danger",
        },
        untoken: {
            msg: "🚫 No existe token válido.",
            type: "danger",
        },
    };

    let triggered = false;

    for (const [key, { msg, type, clear }] of Object.entries(alerts)) {
        if (params.get(key) === "true") {
            showGlobalAlert(msg, type, 6000);
            if (clear) await clearSession();
            triggered = true;
        }
    }

    if (triggered) window.history.replaceState({}, document.title, window.location.pathname);
}

/* =======================================================
   2️⃣ Sidebar responsive toggle (Desktop / Mobile)
   ======================================================= */
function initSidebarToggle() {
    const sidebar = document.getElementById("sidebar");
    const mainContent = document.getElementById("mainContent");
    const toggleBtn = document.getElementById("sidebarToggle");

    if (!sidebar || !mainContent || !toggleBtn) return;

    toggleBtn.addEventListener("click", () => {
        sidebar.classList.toggle("collapsed");
        sidebar.classList.toggle("show"); // para mobile
        mainContent.classList.toggle("expanded");
    });

    const handleResize = () => {
        const isMobile = window.innerWidth < 992;
        sidebar.classList.toggle("collapsed", isMobile);
        mainContent.classList.toggle("expanded", isMobile);
    };

    window.addEventListener("resize", handleResize);
    handleResize();
}

/* =======================================================
   3️⃣ Función de alerta global reutilizable
   ======================================================= */
export function showGlobalAlert(message, type = "info", timeout = 4000) {
    const globalContainer =
        document.getElementById("globalAlerts") ||
        document.getElementById("alertContainer");
    //const globalContainer = document.getElementById("alertContainer");
    /*const globalContainer = document.getElementById("alertContainer") || document.body;*/
    if (!globalContainer) {
        console.warn("⚠️ No se encontró contenedor de alertas.");
        return;
    }

    const wrapper = document.createElement("div");
    wrapper.className = `alert alert-${type} alert-dismissible fade show shadow mt-2`;
    wrapper.setAttribute("role", "alert");
    wrapper.setAttribute("aria-live", "assertive");
    wrapper.setAttribute("aria-atomic", "true");

    wrapper.innerHTML = `
        <div>${message}</div>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;

    globalContainer.appendChild(wrapper);

    if (timeout) {
        setTimeout(() => {
            wrapper.classList.remove("show");
            setTimeout(() => wrapper.remove(), 300);
        }, timeout);
    }
}

/* =======================================================
4️⃣ Eventos globales del sistema
======================================================= */
/* =======================================================
   4️⃣ Eventos globales del sistema
   ======================================================= */
function initGlobalEvents() {
    // 🔁 Evento disparado desde cualquier parte: cerrar sesión global
    document.addEventListener("userLoggedOut", async () => {
        await clearSession();
        showGlobalAlert("👋 Sesión finalizada correctamente.", "info");
        setTimeout(() => (window.location.href = "/"), 1200);
    });

    // 🧠 Logs centralizados (AuthApp, ApiUser, ApiAdmin)
    document.addEventListener("debug:log", (e) => {
        const { label, args, level = "info" } = e.detail;
        const color = {
            info: "#0dcaf0",
            success: "#28a745",
            warn: "#ffc107",
            error: "#dc3545",
            debug: "#6f42c1",
        }[level] || "#aaa";
        console.log(`%c[${level.toUpperCase()}] ${label}`, `color:${color}`, ...args);
    });

    // 🧩 Cambio de sesión (AuthApp → Layout)
    document.addEventListener("session:change", (e) => {
        const { loggedIn, role } = e.detail;
        const msg = loggedIn
            ? `✅ Sesión activa como ${role.toUpperCase()}`
            : "🚪 Sesión cerrada.";
        showGlobalAlert(msg, loggedIn ? "success" : "warning", 4000);
    });

    // 📈 Eventos de métricas (AuthApp telemetry)
    document.addEventListener("metrics:event", (e) => {
        const { event, role, username } = e.detail;
        console.info(`📊 Evento de métrica → ${event} (${role || "?"})`, username);
    });
}

// ===========================
// 🔹 Inicialización del Panel Debug
// ===========================
export function initDebugPanel() {
    const toggle = document.getElementById("debugToggle");

    if (!toggle) return;

    // Cargar estado guardado
    const savedState = localStorage.getItem("debugMode") === "true";
    toggle.checked = savedState;

    // Aplicar el modo actual
    setGlobalDebug(savedState);

    toggle.addEventListener("change", (e) => {
        const enabled = e.target.checked;
        localStorage.setItem("debugMode", enabled);
        setGlobalDebug(enabled);
    });
}

// ===========================
// 🔹 Aplica el modo debug global
// ===========================
function setGlobalDebug(enabled) {
    api_user.debugEnabled = enabled;
    api_admin.debugEnabled = enabled;

    // 🔁 Propaga el modo a AuthApp si está disponible
    if (window.AuthAppInstance) {
        window.AuthAppInstance.debugEnabled = enabled;
    }

    console.info(
        `%c🪲 Debug Mode ${enabled ? "ACTIVADO" : "DESACTIVADO"}`,
        `color: ${enabled ? "#00e676" : "#ff5252"}; font-weight: bold;`
    );
}

// ===========================
// 🔹 Debug Console Flotante
// ===========================
function initDebugConsole() {
    const toggle = document.getElementById("debugToggle");
    const consoleEl = document.getElementById("debugConsole");
    const output = document.getElementById("debugOutput");
    const clearBtn = document.getElementById("clearDebug");

    if (!toggle || !consoleEl) return;

    // Mostrar / ocultar consola según modo
    toggle.addEventListener("change", (e) => {
        const enabled = e.target.checked;
        consoleEl.classList.toggle("hidden", !enabled);
    });

    // Botón limpiar
    clearBtn.addEventListener("click", () => (output.innerHTML = ""));

    // Escuchar logs enviados por las clases
    document.addEventListener("debug:log", (e) => {
        const { label, args } = e.detail;
        const time = new Date().toLocaleTimeString();
        const logLine = document.createElement("div");
        logLine.className = "debug-log";
        logLine.innerHTML = `<time>[${time}]</time> ${label}: ${args
            .map((a) => JSON.stringify(a, null, 2))
            .join(" ")}`;
        output.appendChild(logLine);
        output.scrollTop = output.scrollHeight;
    });
}

