import { ApiUser } from "../api/ApiUser.js";
import { IndexedDBStorage } from "../adapters/IndexedDBStorage.js";
import { showGlobalAlert, GLOBAL_DEBUG } from "../layout.js";
import { SPAHelper } from "../utils/spaHelper.js";

export class UserDashboard {
    constructor() {
        this.debugEnabled = localStorage.getItem("debugMode") === "true"; // toggle localStorage
        this.API_BASE = import.meta.env?.VITE_API_URL || "https://localhost:5000";
        this.storage = new IndexedDBStorage("AuthDB", "tokens");
        this.apiUser = new ApiUser({ baseURL: this.API_BASE, storage: this.storage, debugEnabled: GLOBAL_DEBUG });
        this.debugEnabled = GLOBAL_DEBUG;
        this.userCache = null;
        this.currentUserItemsPage = 1;

        // Cache DOM
        this.loadingSpinner = document.getElementById("loadingSpinner");
        this.dashboardContent = document.getElementById("dashboardContent");

        this.spa = new SPAHelper({
            spinnerId: 'loadingSpinner',
            dashboardId: 'dashboardContent',
            sectionsSelector: '#dashboardContent > section',
            tokenProgressId: 'tokenProgress',
            tokenTimerId: 'tokenTimer',
            fechaId: 'fechaCountry',
            apiUser: this.apiUser
        });
    }
    // =============================
    // 🔹 Logger Inteligente
    // =============================
    _log(level = "info", label = "", ...args) {
        if (!this.debugEnabled) return;

        const time = new Date().toLocaleTimeString();
        const styles = {
            info: "color:#0dcaf0; font-weight:bold;",
            warn: "color:#ffc107; font-weight:bold;",
            error: "color:#dc3545; font-weight:bold;",
            success: "color:#28a745; font-weight:bold;",
            debug: "color:#6f42c1; font-weight:bold;"
        };

        const prefix = {
            info: "ℹ️",
            warn: "⚠️",
            error: "💥",
            success: "✅",
            debug: "🧠"
        }[level] || "🔹";

        console.groupCollapsed(`%c${prefix} [${level.toUpperCase()} ${time}] ${label}`, styles[level] || styles.info);
        console.log(...args);
        console.groupEnd();

        // 🔹 Nuevo → emite al panel flotante
        document.dispatchEvent(new CustomEvent("debug:log", { detail: { label, args } }));
    }

    // Aliases cortos
    _debug(label, ...args) { this._log("debug", label, ...args); }
    _info(label, ...args) { this._log("info", label, ...args); }
    _warn(label, ...args) { this._log("warn", label, ...args); }
    _error(label, ...args) { this._log("error", label, ...args); }
    _success(label, ...args) { this._log("success", label, ...args); }

    async init() {
        try {
            this._info("Inicializando UserDashboard...");
            await this.storage._init();
            await this.apiUser.loadDashboard();
            await this.loadUserCache();
            this._success("Cache de usuario cargada", this.userCache);
            if (!this.userCache?.user_rol) {
                this._warn("Token inválido o expirado");
                return this.redirectToLogin("No hay token válido.");
            }
            this.renderUserSession();
            this._debug("Render completado", this.userCache.user_name);
            this.setupSidebar(this.userCache.user_rol);
            this.spa.showDashboard();
            this.spa.startTokenTimer(this.userCache.expira);

            this.initMenu();
            this.initLogout();
            this.initChat();
            this.initNotifications();

        } catch (err) {
            this._error("Error inicializando dashboard", err);
            this.redirectToLogin("Error inicializando dashboard.");
        }
    }

    async loadUserCache() {
        this._debug("loadUserCache()", "Cargando datos del usuario...");
        try {
            const { username, rol, exp } = await this.apiUser.loadInfoUser();
            this.userCache = { user_name: username, user_rol: rol, expira: exp };
            this._success("User cache recuperada", this.userCache);
            return this.userCache;
 
        } catch (err) {
            this._error("Error al cargar cache", err);
            throw err;
        }
    }

    renderUserSession() {
        if (!this.userCache) return;

        this.dashboardContent.hidden = false;
        this.loadingSpinner.style.display = "none";

        const userEl = document.getElementById("userName");
        if (userEl)
            userEl.textContent = `👋 ${this.userCache.user_name} (${this.userCache.user_rol})`;

        // Renderiza el panel de usuario dinámico
        this.renderUserPanel(this.userCache);
        setTimeout(() => {
            showGlobalAlert(`✨ Bienvenido de nuevo, ${this.userCache.user_name}!`, "success", 3000);
        }, 400);
    }

    renderUserPanel(user) {
        const panel = document.getElementById("userPanelSection");
        if (!panel) return;

        const isAdmin = user.user_rol?.toLowerCase() === "admin";

        const sessionText = isAdmin
            ? "Tienes control total del sistema. No abuses 😏"
            : "Tu sesión está activa y lista para trabajar.";

        const permisos = isAdmin
            ? ["Lectura", "Escritura", "Gestión de usuarios", "Configuración avanzada"]
            : ["Lectura", "Edición limitada"];

        const panelClass = isAdmin ? "user-panel admin fade-in" : "user-panel fade-in";

        panel.innerHTML = `
        <div class="${panelClass}">
            <h5><i class="bi bi-person-circle"></i> Panel de ${isAdmin ? "Administrador" : "Usuario"}</h5>

            <div class="card border-${isAdmin ? "danger" : "primary"} mb-3">
                <div class="card-header bg-${isAdmin ? "danger" : "primary"} text-white">
                    <i class="bi bi-check-circle"></i> Estado de la sesión
                </div>
                <div class="card-body">
                    <p class="card-text">${sessionText}</p>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <i class="bi bi-speedometer2"></i> Resumen
                </div>
                <div class="card-body">
                    <ul>
                        <li><strong>Rol:</strong> ${user.user_rol}</li>
                        <li><strong>Permisos:</strong> ${permisos.join(", ")}</li>
                    </ul>
                </div>
            </div>
        </div>
    `;
    }


    setupSidebar(role) {
        if (!role) return;
        const roleLower = String(role).toLowerCase();
        document.querySelectorAll("#sidebar [class*='role-']").forEach(el => {
            const roles = [...el.classList].filter(c => c.startsWith("role-")).map(c => c.replace("role-", ""));
            el.style.display = roles.includes(roleLower) ? "block" : "none";
        });
    }

    initMenu() {
        document.querySelectorAll("#sidebar button[data-action]").forEach(btn => {
            btn.addEventListener("click", async () => {
                const action = btn.dataset.action;
                this._debug("Menu click → acción:", action);

                if (action === 'item-usuario') {
                    this.spa.switchSection("#userItemsSection");
                    await this.loadItems();
                } else if (action === 'chat-usuario') {
                    this.spa.switchSection("#userChatSection");
                }
            });
        });

        document.getElementById("addItemBtn")?.addEventListener("click", async () => {
            const name = document.getElementById("itemNameInput").value.trim();
            const desc = document.getElementById("itemDescInput").value.trim();
            if (!name || !desc) return showGlobalAlert("Completa todos los campos.", "warning");
            await this.apiUser.createItem({ name, description: desc });
            document.getElementById("itemNameInput").value = "";
            document.getElementById("itemDescInput").value = "";
            await this.loadItems();
        });
    }

    async loadItems() {
        const { loadItemUser } = await import("../modules/items.js");
        await loadItemUser(this.currentUserItemsPage, this.apiUser);
    }

    initLogout() {
        const handleLogout = async (reason = "close") => {
            this._info("initLogout()", reason);
            await this.apiUser.logout({ reason });
            this.redirectToLogin("Sesión cerrada.");
        };
        
        document.getElementById("logoutBtn")?.addEventListener("click", () => handleLogout("manual"));
        window.addEventListener("beforeunload", () => handleLogout("close"));
        document.addEventListener("userLoggedOut", () => handleLogout("event"));
    }

    initChat() {
        const input = document.getElementById("chatInput");
        const btn = document.getElementById("sendChatBtn");
        const chatBox = document.getElementById("chatMessages");
        btn?.addEventListener("click", async () => {
            const msg = input.value.trim();
            if (!msg) return;
            await this.apiUser.sendMessage(msg);
            input.value = "";
            const p = document.createElement("p"); p.textContent = `Yo: ${msg}`; chatBox.appendChild(p);
        });
    }

    initNotifications() {
        document.addEventListener("userNotification", ({ detail }) => {
            showGlobalAlert(`🔔 ${detail.message}`, "info", 4000);
        });
    }

    redirectToLogin(msg) {
        this._warn("Redirigiendo al login", msg);
        if (msg) showGlobalAlert(msg, "danger", 5000);
        location.replace("/");
    }

}

document.addEventListener("DOMContentLoaded", () => new UserDashboard().init());
