export class SPAHelper {
    constructor({ spinnerId, dashboardId, sectionsSelector, tokenProgressId, tokenTimerId, fechaId, apiUser }) {
        this.spinner = document.getElementById(spinnerId);
        this.dashboard = document.getElementById(dashboardId);
        this.sections = document.querySelectorAll(sectionsSelector);
        this.tokenProgress = document.getElementById(tokenProgressId);
        this.tokenTimer = document.getElementById(tokenTimerId);
        this.fechaEl = document.getElementById(fechaId);
        this.apiUser = apiUser;
        this.tokenTimerInterval = null;
        this.activeSection = null;
    }

    showDashboard() {
        this.spinner.style.display = "none";
        this.dashboard.style.display = "block";
        this.dashboard.classList.add("fade-in");
    }

    showSpinner() {
        this.dashboard.style.display = "none";
        this.spinner.style.display = "flex";
    }

    switchSection(selector) {
        this.sections.forEach(s => s.style.display = "none");
        const sec = document.querySelector(selector);
        if (sec) sec.style.display = "block";
        this.activeSection = selector;
    }

    // dentro de SPAHelper (o donde tengas startTokenTimer)
    startTokenTimer(expTimestamp) {
        const timerEl = document.getElementById("tokenTimer");
        const progressBar = document.getElementById("tokenProgress");
        if (!timerEl || !progressBar || !expTimestamp) return;

        const totalDuration = expTimestamp * 1000 - Date.now();
        let lastUpdate = performance.now();
        let refreshTriggered = false;

        const update = (now) => {
            const delta = now - lastUpdate;
            if (delta >= 1000) {
                lastUpdate = now;
                const remaining = expTimestamp * 1000 - Date.now();
                const pct = Math.max(0, Math.floor((remaining / totalDuration) * 100));
                this.updateProgressBar(progressBar, pct);
                timerEl.textContent = `⏱ ${this.formatRemaining(remaining)}`;
                if (!refreshTriggered && remaining <= 30000) {
                    refreshTriggered = true;
                    this.apiUser.tryRefreshToken();
                }
            }
            if (expTimestamp * 1000 > Date.now()) {
                requestAnimationFrame(update);
            } else {
                progressBar.classList.add("bg-danger");
                timerEl.textContent = "⛔ Token expirado";
            }
        };
        requestAnimationFrame(update);
    }

    updateProgressBar(progressBar, percentage) {
        progressBar.style.width = `${percentage}%`;

        progressBar.classList.remove("bg-success", "bg-warning", "bg-danger");
        if (percentage <= 29) progressBar.classList.add("bg-danger");
        else if (percentage <= 49) progressBar.classList.add("bg-warning");
        else progressBar.classList.add("bg-success");
    }
    resetProgressBar() {
        const progressBar = document.getElementById("tokenProgress");
        if (progressBar) {
            progressBar.classList.remove("bg-danger", "bg-warning", "bg-success");
            progressBar.classList.add("bg-success");
        }
    }

    formatDateSantiago(expTimestamp) {
        return new Date(expTimestamp * 1000).toLocaleString("es-CL", {
            timeZone: "America/Santiago",
            hour12: false,
        });
    }
    formatRemaining(ms) {
        const totalSec = Math.floor(ms / 1000);
        const hours = Math.floor(totalSec / 3600);
        const minutes = Math.floor((totalSec % 3600) / 60);
        const seconds = totalSec % 60;
        return hours > 0 ? `${hours}h ${minutes}m ${seconds}s` : `${minutes}m ${seconds}s`;
    }
    // Flash de token progress
    flashToken() {
        if (!this.tokenProgress) return;
        this.tokenProgress.classList.add('flash');
        setTimeout(() => this.tokenProgress.classList.remove('flash'), 800);
    }
    dispatchUserLoggedOut() {
        document.dispatchEvent(new CustomEvent("userLoggedOut"));
    }
}
