// AuthApp.js – versión mejorada
import { ApiUser } from "./api/ApiUser.js";
import { ApiAdmin } from "./api/ApiAdmin.js";
import { IndexedDBStorage } from "./adapters/IndexedDBStorage.js";
import { showGlobalAlert, GLOBAL_DEBUG } from "./layout.js";
import { validateForm, decodeJwt } from "./utils/helper.js";

export class AuthApp {
    constructor() {
        this.API_BASE = import.meta.env?.VITE_API_URL || "https://localhost:5000";
        this.DEBUG = import.meta.env?.VITE_DEBUG_MODE === "true";
        this.storage = new IndexedDBStorage("AuthDB", "tokens");
        this.api_admin = new ApiAdmin({ baseURL: this.API_BASE, storage: this.storage, debugEnabled: GLOBAL_DEBUG });
        this.api_user = new ApiUser({ baseURL: this.API_BASE, storage: this.storage, debugEnabled: GLOBAL_DEBUG });
        this.debugEnabled = GLOBAL_DEBUG;
        this.sessionCache = null;
        this.refreshInProgress = false;
        this.tokenTimeout = null;
    }

    // ==============================
    // 🚀 INIT PRINCIPAL
    // ==============================
    async init() {
        try {
            await this.storage._init();
            this._log("debug","AuthApp inicializado", { API_BASE: this.API_BASE, DEBUG: this.debugEnabled });

            // 🔍 Verificar tokens locales
            const tokenCheck = await this._checkStoredTokens();
            if (tokenCheck.exists) {
                this.sessionCache = tokenCheck;
                this._emitSessionChange(true, tokenCheck.rol);
                this.scheduleNextTokenCheck();
                return this.redirectByRole(tokenCheck.rol);
            }

            const isValid = await this.checkSession();
            if (isValid) {
                this.scheduleNextTokenCheck();
                return this.redirectByRole(this.sessionCache.rol);
            }

            this._log("debug","No hay sesión activa. Mostrando login.");
            this.initLoginForm();

        } catch (err) {
            console.error("❌ Error en init:", err);
            showGlobalAlert("Error inesperado. Intenta nuevamente.", "danger", 5000);
        }
    }

    // ==============================
    // 🧩 TOKEN & SESIÓN LOCAL
    // ==============================
    async _checkStoredTokens() {
        const adminToken = await this.api_admin.accessToken("admin");
        const userToken = await this.api_user.accessToken("user");
        const now = Date.now();

        if (adminToken && userToken) {
            console.warn("⚠️ Tokens duplicados detectados → limpiando");
            await this.storage.clear();
            return { exists: false, rol: null };
        }

        const adminDecoded = decodeJwt(adminToken);
        const userDecoded = decodeJwt(userToken);

        if (adminToken && adminDecoded?.exp * 1000 > now)
            return { exists: true, rol: "admin", exp: adminDecoded.exp };

        if (userToken && userDecoded?.exp * 1000 > now)
            return { exists: true, rol: "user", exp: userDecoded.exp };

        return { exists: false, rol: null };
    }

    async checkSession() {
        for (const role of ["admin", "user"]) {
            const tokenEntry = await this.storage.get(`access_token_${role}`);
            if (!tokenEntry?.value) continue;
            const decoded = decodeJwt(tokenEntry.value);
            if (decoded?.exp * 1000 > Date.now()) {
                this.sessionCache = { username: decoded.sub, rol: role, exp: decoded.exp };
                this._emitSessionChange(true, role);
                return true;
            }
        }
        return false;
    }

    // ==============================
    // ⏱️ TOKEN WATCHER (DYNAMIC)
    // ==============================
    scheduleNextTokenCheck() {
        if (this.tokenTimeout) clearTimeout(this.tokenTimeout);

        const role = this.sessionCache?.rol;
        if (!role) return;

        this.storage.get(`access_token_${role}`).then(tokenEntry => {
            if (!tokenEntry?.value) return;

            const decoded = decodeJwt(tokenEntry.value);
            const remaining = decoded.exp * 1000 - Date.now();
            const checkIn = Math.max(remaining - 60000, 10000); // 1 min antes o mínimo 10s

            this._log("debug",`⌛ Próximo check de token ${role} en ${(checkIn / 1000).toFixed(1)}s`);
            this.tokenTimeout = setTimeout(() => this._checkAndRefreshToken(role), checkIn);
        });
    }

    async _checkAndRefreshToken(role) {
        try {
            if (this.refreshInProgress) return;
            const tokenEntry = await this.storage.get(`access_token_${role}`);
            if (!tokenEntry?.value) return;

            const decoded = decodeJwt(tokenEntry.value);
            const remaining = decoded.exp * 1000 - Date.now();

            if (remaining < 60000) {
                await this.refreshSession(role);
            } else if (remaining <= 0) {
                await this.apiLogout(role);
                this.redirectToLogin("⚠️ Tu sesión expiró. Iniciá sesión nuevamente.");
                return;
            }

            this.scheduleNextTokenCheck();

        } catch (err) {
            console.error("Error verificando token:", err);
            this.redirectToLogin("🚫 Error al validar sesión.");
        }
    }

    async refreshSession(role) {
        // 🔒 Evitar refresh simultáneo (lock global)
        if (localStorage.getItem("refreshLock") === "true") return;
        localStorage.setItem("refreshLock", "true");

        try {
            this._log("debug",`♻️ Intentando refresh de token (${role})`);
            this.refreshInProgress = true;

            const api = role === "admin" ? this.api_admin : this.api_user;
            const res = await api.tryRefreshToken();

            if (res?.access_token) {
                await this.storage.set(`access_token_${role}`, { value: res.access_token });
                const decoded = decodeJwt(res.access_token);
                this.sessionCache.exp = decoded.exp;
                this._log("success", "refreshSession", `Token ${role} renovado`, decoded);
            } else {
                throw new Error("Refresh sin token válido");
            }

        } catch (err) {
            console.error("Error refrescando token:", err);
            await this.apiLogout(role);
            this.redirectToLogin("🚫 Sesión caducada o inválida.");
        } finally {
            localStorage.removeItem("refreshLock");
            this.refreshInProgress = false;
        }
    }

    // ==============================
    // 🧾 LOGIN FLOW
    // ==============================
    initLoginForm() {
        const form = document.getElementById("loginForm");
        const btn = document.getElementById("loginBtn");
        const statusMsg = document.getElementById("loginStatusMsg");
        if (!form || !btn || !statusMsg) return;

        form.addEventListener("submit", async e => {
            e.preventDefault();
            if (!validateForm(form)) return showGlobalAlert("Completa todos los campos.", "warning", 3000);

            const username = form.username.value.trim();
            const password = form.password.value;

            try {
                btn.classList.add("loading");
                statusMsg.textContent = "Validando credenciales...";
                statusMsg.className = "login-status active loading";

                const data = await this.doLogin(username, password);
                const rol = (data?.rol || "user").toLowerCase();

                const decoded = decodeJwt(data.access_token);
                this.sessionCache = { rol, username, exp: decoded.exp };


                showGlobalAlert("✅ Bienvenido, redirigiendo...", "success", 1500);
                this.scheduleNextTokenCheck();

                setTimeout(() => this.redirectByRole(rol), 1200);

            } catch (err) {
                this._log("error","Login", err);
                showGlobalAlert("Credenciales inválidas o error de red.", "danger", 5000);
            } finally {
                btn.classList.remove("loading");
                setTimeout(() => statusMsg.classList.remove("active"), 3000);
            }
        });
    }

    async doLogin(username, password) {
        return username.includes("admin")
            ? this.api_admin.login(username, password)
            : this.api_user.login(username, password);
    }

    async apiLogout(role) {
        const api = role === "admin" ? this.api_admin : this.api_user;
        await api.logout("close");
        await this.storage.clear();
        this.sessionCache = null;

        document.dispatchEvent(new CustomEvent("session:change", {
            detail: { loggedIn: false, role }
        }));

        this._log("info", "Logout", `Sesión ${role} cerrada`);
    }

    redirectByRole(rol) {
        document.dispatchEvent(new CustomEvent("session:change", {
            detail: { loggedIn: true, role: rol }
        }));
        const routes = { admin: "/admin/dashboard", user: "/user/dashboard" };
        window.location.href = routes[rol] || "/";
    }

    redirectToLogin(msg) {
        if (msg) showGlobalAlert(msg, "danger", 5000);
        if (window.location.pathname !== "/") location.replace("/?logout=true");
    }

    // ==============================
    // 🧠 LOGS + TELEMETRÍA + EVENTOS
    // ==============================
    // =============================
    // 🔹 Logger Inteligente + Eventos Globales
    // =============================
    _log(level = "info", label = "", ...args) {
        if (!this.debugEnabled) return;

        const time = new Date().toLocaleTimeString();
        const styles = {
            info: "color:#0dcaf0; font-weight:bold;",
            warn: "color:#ffc107; font-weight:bold;",
            error: "color:#dc3545; font-weight:bold;",
            success: "color:#28a745; font-weight:bold;",
            debug: "color:#6f42c1; font-weight:bold;"
        };

        const prefix = {
            info: "ℹ️",
            warn: "⚠️",
            error: "💥",
            success: "✅",
            debug: "🧠"
        }[level] || "🔹";

        console.groupCollapsed(`%c${prefix} [${level.toUpperCase()} ${time}] ${label}`, styles[level] || styles.info);
        console.log(...args);
        console.groupEnd();

        // 🚀 Emite evento global para DebugConsole o panel flotante
        document.dispatchEvent(new CustomEvent("debug:log", {
            detail: { level, label, args }
        }));
    }

}

// Auto-inicialización
document.addEventListener("DOMContentLoaded", () => {
    window.AuthAppInstance = new AuthApp();
    window.AuthAppInstance.init();
});
